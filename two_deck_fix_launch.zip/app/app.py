# app/app.py
# Route the main launcher to the two-deck UI.
from app.ui.main_two_decks import run_app

if __name__ == "__main__":
    run_app()
